# darcula.nbm

Netbeans plugin for the darcula theme. Since the nbm-file is not available anymore after the old plugin repository was switched off and someone asked for it (https://stackoverflow.com/questions/69616534/where-or-how-can-i-download-darcula-laf-for-netbean-8-2/69988226#69988226), here a copy that I found on my hard drive, for those who still need it.
